#include "show.h"
#include "oled.h"

void show_task(void *pvParameters)
{
   u32 lastWakeTime = getSysTickCnt();
   while(1)
    {	

			vTaskDelayUntil(&lastWakeTime, F2T(RATE_50_HZ));

			oled_show();    
    }
}

void show_num(int num)
{
	OLED_ShowNumber(10,10,num,2, 15);
	OLED_Refresh_Gram(); //refresh the OLED RAM
}

void timer_task(void *pvParameters)
{
	 int a = 0;
   u32 lastWakeTime = getSysTickCnt();
      while(1)
    {
      
			vTaskDelayUntil(&lastWakeTime, F2T(RATE_50_HZ));
			show_num(a);    
			delay_ms(1000);
			a++;
    }
}



void oled_show(void)
{
     //To DO
	 
	 OLED_ShowString(0,0,"Ben");
	 //call some function in oled to display something

	 OLED_Refresh_Gram(); //refresh the OLED RAM

	  		
	}


