#ifndef __BT_H
#define __BT_H
#include "sys.h"
#include "system.h"

//BT Port definition
#define BT_TASK_PRIO		3
#define BT_STK_SIZE 		128


#define BT_PORT GPIOD
#define BT_PIN GPIO_Pin_5 // OR MAYBE 6 IDK LOL
#define BT PDin(5)
/*----------------------------------*/

void bt_Init(void);
void bt_task(void *pvParameters);
extern int bt_Count;
#endif
