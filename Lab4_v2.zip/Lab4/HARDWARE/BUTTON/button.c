#include "button.h"

int Bt_Count;//BT blink Delay 

//BT initialization
void BT_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE); //Enable APB Clock
	
	GPIO_InitStructure.GPIO_Pin = BT_PIN;				//BT Pin
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_PP;	//Push pull output
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//50M
	GPIO_Init(BT_PORT, &GPIO_InitStructure);			//Initialize BT GPIO
	GPIO_SetBits(BT_PORT,BT_PIN);
}

void led_task(void *pvParameters)
{
   //
}  
